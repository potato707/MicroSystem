"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, StickyNote, Trash2 } from "lucide-react"
import { apiClient } from "@/lib/api-client"
import type { EmployeeNote, Employee } from "@/lib/types"

export default function NotesPage() {
  const router = useRouter()
  const [notes, setNotes] = useState<EmployeeNote[]>([])
  const [employees, setEmployees] = useState<Employee[]>([])
  const [loading, setLoading] = useState(true)
  const [createDialogOpen, setCreateDialogOpen] = useState(false)
  const [formData, setFormData] = useState({
    note: "",
    employee: "",
    created_by: "", // This should be set to current user's ID
  })
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    if (!apiClient.isAuthenticated()) {
      router.push("/login")
      return
    }
    loadData()
  }, [router])

  const loadData = async () => {
    try {
      setLoading(true)
      const [notesData, employeesData] = await Promise.all([
        apiClient.get<EmployeeNote[]>("/hr/notes/"),
        apiClient.get<Employee[]>("/hr/employees/"),
      ])
      setNotes(notesData)
      setEmployees(employeesData)

      // Set created_by to first employee ID as default (in real app, use current user)
      if (employeesData.length > 0 && !formData.created_by) {
        setFormData((prev) => ({ ...prev, created_by: employeesData[0].id }))
      }
    } catch (error) {
      console.error("[v0] Failed to load notes:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitting(true)

    try {
      await apiClient.post("/hr/notes/", formData)
      setCreateDialogOpen(false)
      setFormData({
        note: "",
        employee: "",
        created_by: formData.created_by,
      })
      await loadData()
    } catch (error) {
      console.error("[v0] Failed to create note:", error)
      alert("Failed to create note")
    } finally {
      setSubmitting(false)
    }
  }

  const handleDelete = async (id: number) => {
    if (!confirm("Are you sure you want to delete this note?")) return

    try {
      await apiClient.delete(`/hr/notes/${id}/`)
      await loadData()
    } catch (error) {
      console.error("[v0] Failed to delete note:", error)
      alert("Failed to delete note")
    }
  }

  const getEmployeeName = (employeeId: string) => {
    const employee = employees.find((emp) => emp.id === employeeId)
    return employee?.name || "Unknown"
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-3xl font-heading font-bold">Notes</h1>
            <p className="text-muted-foreground mt-1">Manage employee notes and observations</p>
          </div>
          <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add Note
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add New Note</DialogTitle>
                <DialogDescription>Create a note for an employee</DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="employee">Employee *</Label>
                  <Select
                    value={formData.employee}
                    onValueChange={(value) => setFormData({ ...formData, employee: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select employee" />
                    </SelectTrigger>
                    <SelectContent>
                      {employees.map((emp) => (
                        <SelectItem key={emp.id} value={emp.id}>
                          {emp.name} - {emp.position}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="note">Note *</Label>
                  <Textarea
                    id="note"
                    value={formData.note}
                    onChange={(e) => setFormData({ ...formData, note: e.target.value })}
                    placeholder="Enter your note here..."
                    required
                    rows={5}
                  />
                </div>
                <div className="flex justify-end gap-2">
                  <Button type="button" variant="outline" onClick={() => setCreateDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={submitting}>
                    {submitting ? "Adding..." : "Add Note"}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Notes</CardTitle>
              <StickyNote className="h-5 w-5 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{notes.length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">This Week</CardTitle>
              <StickyNote className="h-5 w-5 text-secondary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {
                  notes.filter((note) => {
                    const noteDate = new Date(note.created_date)
                    const weekAgo = new Date()
                    weekAgo.setDate(weekAgo.getDate() - 7)
                    return noteDate >= weekAgo
                  }).length
                }
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Employees with Notes</CardTitle>
              <StickyNote className="h-5 w-5 text-chart-3" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{new Set(notes.map((n) => n.employee)).size}</div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>All Notes</CardTitle>
            <CardDescription>View and manage employee notes</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="text-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
                <p className="mt-4 text-sm text-muted-foreground">Loading notes...</p>
              </div>
            ) : notes.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-muted-foreground">No notes found</p>
              </div>
            ) : (
              <div className="space-y-4">
                {notes.map((note) => (
                  <Card key={note.id}>
                    <CardHeader>
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1">
                          <CardTitle className="text-base">Note for {getEmployeeName(note.employee)}</CardTitle>
                          <CardDescription className="mt-1">
                            Created on {new Date(note.created_date).toLocaleDateString()} at{" "}
                            {new Date(note.created_date).toLocaleTimeString()}
                          </CardDescription>
                        </div>
                        <Button variant="ghost" size="icon" onClick={() => handleDelete(note.id)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-muted-foreground whitespace-pre-wrap">{note.note}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}

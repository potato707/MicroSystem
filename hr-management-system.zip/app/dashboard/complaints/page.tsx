"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Plus, MessageSquare, AlertCircle, Clock } from "lucide-react"
import { apiClient } from "@/lib/api-client"
import type { Complaint, UrgencyLevel, ComplaintStatus } from "@/lib/types"

export default function ComplaintsPage() {
  const router = useRouter()
  const [complaints, setComplaints] = useState<Complaint[]>([])
  const [loading, setLoading] = useState(true)
  const [createDialogOpen, setCreateDialogOpen] = useState(false)
  const [detailsDialogOpen, setDetailsDialogOpen] = useState(false)
  const [selectedComplaint, setSelectedComplaint] = useState<Complaint | null>(null)
  const [replyMessage, setReplyMessage] = useState("")
  const [submittingReply, setSubmittingReply] = useState(false)
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    urgency: "medium" as UrgencyLevel,
    attachment_links: [] as string[],
  })
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    if (!apiClient.isAuthenticated()) {
      router.push("/login")
      return
    }
    loadComplaints()
  }, [router])

  const loadComplaints = async () => {
    try {
      setLoading(true)
      const data = await apiClient.get<Complaint[]>("/hr/complaints/list/")
      setComplaints(data)
    } catch (error) {
      console.error("[v0] Failed to load complaints:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitting(true)

    try {
      await apiClient.post("/hr/complaints/", formData)
      setCreateDialogOpen(false)
      setFormData({ title: "", description: "", urgency: "medium", attachment_links: [] })
      await loadComplaints()
    } catch (error) {
      console.error("[v0] Failed to create complaint:", error)
      alert("Failed to create complaint")
    } finally {
      setSubmitting(false)
    }
  }

  const handleReply = async () => {
    if (!selectedComplaint || !replyMessage.trim()) return

    setSubmittingReply(true)
    try {
      await apiClient.post(`/hr/complaints/${selectedComplaint.id}/reply/`, {
        message: replyMessage,
        attachment_links: [],
      })
      setReplyMessage("")
      await loadComplaints()
      // Refresh the selected complaint details
      const updatedComplaints = await apiClient.get<Complaint[]>("/hr/complaints/list/")
      const updated = updatedComplaints.find((c) => c.id === selectedComplaint.id)
      if (updated) setSelectedComplaint(updated)
    } catch (error) {
      console.error("[v0] Failed to submit reply:", error)
      alert("Failed to submit reply")
    } finally {
      setSubmittingReply(false)
    }
  }

  const getStatusColor = (status: ComplaintStatus) => {
    switch (status) {
      case "open":
        return "bg-chart-3 text-white"
      case "in_review":
        return "bg-secondary text-secondary-foreground"
      case "answered":
        return "bg-primary text-primary-foreground"
      case "closed":
        return "bg-muted text-muted-foreground"
      default:
        return "bg-muted text-muted-foreground"
    }
  }

  const getUrgencyColor = (urgency: UrgencyLevel) => {
    switch (urgency) {
      case "high":
        return "bg-destructive text-destructive-foreground"
      case "medium":
        return "bg-chart-3 text-white"
      case "low":
        return "bg-muted text-muted-foreground"
      default:
        return "bg-muted text-muted-foreground"
    }
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-3xl font-heading font-bold">Complaints</h1>
            <p className="text-muted-foreground mt-1">Manage employee complaints and feedback</p>
          </div>
          <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                New Complaint
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Submit Complaint</DialogTitle>
                <DialogDescription>Describe your complaint or concern</DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="title">Title *</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    placeholder="Brief summary of the complaint"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">Description *</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Provide detailed information about your complaint"
                    required
                    rows={5}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="urgency">Urgency *</Label>
                  <Select
                    value={formData.urgency}
                    onValueChange={(value) => setFormData({ ...formData, urgency: value as UrgencyLevel })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex justify-end gap-2">
                  <Button type="button" variant="outline" onClick={() => setCreateDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={submitting}>
                    {submitting ? "Submitting..." : "Submit Complaint"}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Open</CardTitle>
              <MessageSquare className="h-5 w-5 text-chart-3" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{complaints.filter((c) => c.status === "open").length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">In Review</CardTitle>
              <Clock className="h-5 w-5 text-secondary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{complaints.filter((c) => c.status === "in_review").length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Answered</CardTitle>
              <MessageSquare className="h-5 w-5 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{complaints.filter((c) => c.status === "answered").length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">High Priority</CardTitle>
              <AlertCircle className="h-5 w-5 text-destructive" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{complaints.filter((c) => c.urgency === "high").length}</div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>All Complaints</CardTitle>
            <CardDescription>View and respond to complaints</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="text-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
                <p className="mt-4 text-sm text-muted-foreground">Loading complaints...</p>
              </div>
            ) : complaints.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-muted-foreground">No complaints found</p>
              </div>
            ) : (
              <div className="space-y-4">
                {complaints.map((complaint) => (
                  <Card
                    key={complaint.id}
                    className="cursor-pointer hover:bg-muted/50 transition-colors"
                    onClick={() => {
                      setSelectedComplaint(complaint)
                      setDetailsDialogOpen(true)
                    }}
                  >
                    <CardHeader>
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1">
                          <CardTitle className="text-lg">{complaint.title}</CardTitle>
                          <CardDescription className="mt-1">
                            By {complaint.employee_name} • {new Date(complaint.created_at).toLocaleDateString()}
                          </CardDescription>
                        </div>
                        <div className="flex gap-2">
                          <Badge className={getStatusColor(complaint.status)}>{complaint.status}</Badge>
                          <Badge className={getUrgencyColor(complaint.urgency)}>{complaint.urgency}</Badge>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-muted-foreground line-clamp-2">{complaint.description}</p>
                      {complaint.replies.length > 0 && (
                        <p className="text-sm text-primary mt-2">{complaint.replies.length} replies</p>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Dialog open={detailsDialogOpen} onOpenChange={setDetailsDialogOpen}>
          <DialogContent className="max-w-3xl max-h-[90vh]">
            <DialogHeader>
              <DialogTitle>Complaint Details</DialogTitle>
            </DialogHeader>
            {selectedComplaint && (
              <div className="space-y-4">
                <div>
                  <h3 className="text-xl font-heading font-bold">{selectedComplaint.title}</h3>
                  <div className="flex items-center gap-2 mt-2">
                    <Badge className={getStatusColor(selectedComplaint.status)}>{selectedComplaint.status}</Badge>
                    <Badge className={getUrgencyColor(selectedComplaint.urgency)}>{selectedComplaint.urgency}</Badge>
                    <span className="text-sm text-muted-foreground">
                      By {selectedComplaint.employee_name} •{" "}
                      {new Date(selectedComplaint.created_at).toLocaleDateString()}
                    </span>
                  </div>
                </div>

                <Separator />

                <div>
                  <p className="text-sm font-medium mb-2">Description</p>
                  <p className="text-sm text-muted-foreground">{selectedComplaint.description}</p>
                </div>

                <Separator />

                <div>
                  <p className="text-sm font-medium mb-3">Replies ({selectedComplaint.replies.length})</p>
                  <ScrollArea className="h-[200px] pr-4">
                    {selectedComplaint.replies.length === 0 ? (
                      <p className="text-sm text-muted-foreground text-center py-4">No replies yet</p>
                    ) : (
                      <div className="space-y-4">
                        {selectedComplaint.replies.map((reply) => (
                          <div key={reply.id} className="bg-muted p-3 rounded-lg">
                            <div className="flex items-center justify-between mb-2">
                              <p className="text-sm font-medium">{reply.user_name}</p>
                              <p className="text-xs text-muted-foreground">
                                {new Date(reply.created_at).toLocaleDateString()}
                              </p>
                            </div>
                            <p className="text-sm">{reply.message}</p>
                          </div>
                        ))}
                      </div>
                    )}
                  </ScrollArea>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="reply">Add Reply</Label>
                  <Textarea
                    id="reply"
                    value={replyMessage}
                    onChange={(e) => setReplyMessage(e.target.value)}
                    placeholder="Type your reply here..."
                    rows={3}
                  />
                  <div className="flex justify-end">
                    <Button onClick={handleReply} disabled={submittingReply || !replyMessage.trim()}>
                      {submittingReply ? "Sending..." : "Send Reply"}
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  )
}

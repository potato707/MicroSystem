"use client"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Edit } from "lucide-react"
import type { Employee } from "@/lib/types"
import { EmployeeForm } from "./employee-form"

interface EmployeeDetailsProps {
  employee: Employee
  onUpdate: () => void
}

export function EmployeeDetails({ employee, onUpdate }: EmployeeDetailsProps) {
  const [editDialogOpen, setEditDialogOpen] = useState(false)

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-primary text-primary-foreground"
      case "vacation":
        return "bg-secondary text-secondary-foreground"
      case "probation":
        return "bg-chart-3 text-white"
      case "resigned":
      case "terminated":
        return "bg-muted text-muted-foreground"
      default:
        return "bg-muted text-muted-foreground"
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between">
        <div>
          <h2 className="text-2xl font-heading font-bold">{employee.name}</h2>
          <p className="text-muted-foreground">{employee.position}</p>
        </div>
        <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
          <DialogTrigger asChild>
            <Button variant="outline" size="sm">
              <Edit className="mr-2 h-4 w-4" />
              Edit
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Edit Employee</DialogTitle>
            </DialogHeader>
            <EmployeeForm
              employee={employee}
              onSuccess={() => {
                setEditDialogOpen(false)
                onUpdate()
              }}
            />
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <div>
          <p className="text-sm font-medium text-muted-foreground">Status</p>
          <Badge className={`mt-1 ${getStatusColor(employee.status)}`}>{employee.status}</Badge>
        </div>
        <div>
          <p className="text-sm font-medium text-muted-foreground">Department</p>
          <p className="mt-1">{employee.department}</p>
        </div>
      </div>

      <Separator />

      <div className="grid gap-4 md:grid-cols-2">
        <div>
          <p className="text-sm font-medium text-muted-foreground">Email</p>
          <p className="mt-1">{employee.email}</p>
        </div>
        <div>
          <p className="text-sm font-medium text-muted-foreground">Phone</p>
          <p className="mt-1">{employee.phone}</p>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <div>
          <p className="text-sm font-medium text-muted-foreground">Hire Date</p>
          <p className="mt-1">{new Date(employee.hire_date).toLocaleDateString()}</p>
        </div>
        <div>
          <p className="text-sm font-medium text-muted-foreground">Salary</p>
          <p className="mt-1">${Number.parseFloat(employee.salary).toLocaleString()}</p>
        </div>
      </div>

      <Separator />

      <div>
        <p className="text-sm font-medium text-muted-foreground">Address</p>
        <p className="mt-1">{employee.address}</p>
      </div>

      <div>
        <p className="text-sm font-medium text-muted-foreground">Emergency Contact</p>
        <p className="mt-1">{employee.emergency_contact}</p>
      </div>

      <Separator />

      <div className="grid gap-4 md:grid-cols-2">
        <div>
          <p className="text-sm font-medium text-muted-foreground">Username</p>
          <p className="mt-1">{employee.username}</p>
        </div>
        <div>
          <p className="text-sm font-medium text-muted-foreground">Role</p>
          <p className="mt-1 capitalize">{employee.role}</p>
        </div>
      </div>
    </div>
  )
}

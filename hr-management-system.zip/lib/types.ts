// TypeScript types based on OpenAPI schema

export type EmployeeStatus = "active" | "vacation" | "resigned" | "terminated" | "probation"
export type AttendanceStatus = "present" | "absent" | "late" | "on_leave"
export type LeaveRequestStatus = "pending" | "approved" | "rejected"
export type ComplaintStatus = "open" | "in_review" | "answered" | "closed"
export type UrgencyLevel = "low" | "medium" | "high"
export type DocumentType = "certificate" | "contract" | "cv" | "id" | "other"

export interface Employee {
  id: string
  name: string
  position: string
  department: string
  hire_date: string
  salary: string
  status: EmployeeStatus
  phone: string
  email: string
  address: string
  emergency_contact: string
  profile_picture?: string | null
  username: string
  role: string
  payroll_time_left: string
  attachments: EmployeeDocument[]
}

export interface EmployeeAttendance {
  id: string
  employee: string
  employee_name: string
  date: string
  check_in?: string | null
  check_out?: string | null
  status: AttendanceStatus
}

export interface LeaveRequest {
  id: string
  employee: string
  employee_name: string
  start_date: string
  end_date: string
  reason: string
  status: LeaveRequestStatus
  created_at: string
  updated_at: string
}

export interface Complaint {
  id: string
  employee: string
  employee_name: string
  title: string
  description: string
  status: ComplaintStatus
  urgency: UrgencyLevel
  created_at: string
  updated_at: string
  attachments: ComplaintAttachment[]
  replies: ComplaintReply[]
}

export interface ComplaintAttachment {
  id: number
  file_url: string
  uploaded_at: string
}

export interface ComplaintReply {
  id: number
  user_name: string
  message: string
  created_at: string
  attachments: ComplaintAttachment[]
}

export interface EmployeeDocument {
  id: number
  document_type: DocumentType
  title: string
  file_url: string
  upload_date: string
  description?: string
  employee: string
}

export interface EmployeeNote {
  id: number
  note: string
  created_date: string
  employee: string
  created_by: string
}
